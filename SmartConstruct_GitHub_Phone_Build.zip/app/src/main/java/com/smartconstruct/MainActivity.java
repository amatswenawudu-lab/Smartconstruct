package com.smartconstruct;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    int level=1, step=0; String player="";

    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(30,40,45)); t.setPadding(8,12,8,12); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    public void onCreate(Bundle b){super.onCreate(b); showSetup();}
    void base(){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,28); root.setBackgroundColor(Color.WHITE); setContentView(root);
        TextView h=tv("SMART CONSTRUCT",30); h.setTextColor(Color.rgb(38,50,56)); h.setGravity(Gravity.CENTER); root.addView(h);
        TextView sub=tv("Build it. Master it. Advance.",16); sub.setGravity(Gravity.CENTER); root.addView(sub);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content,new LinearLayout.LayoutParams(-1,-1));
    }
    void showSetup(){base(); content.addView(tv("👷 Player Setup",24)); content.addView(tv("Enter your name and age. Your age determines the difficulty.",16));
        EditText name=new EditText(this); name.setHint("Your name"); content.addView(name);
        EditText age=new EditText(this); age.setHint("Your age"); age.setInputType(2); content.addView(age);
        Button start=btn("START BUILDING"); content.addView(start);
        start.setOnClickListener(v->{player=name.getText().toString().trim(); int a; try{a=Integer.parseInt(age.getText().toString());}catch(Exception e){a=0;}
            if(player.isEmpty()||a<1){Toast.makeText(this,"Please enter your name and a valid age.",Toast.LENGTH_SHORT).show();return;}
            String d=a<12?"EASY":a<18?"NORMAL":"DIFFICULT"; showLevel(d);});
    }
    void showLevel(String difficulty){base(); content.addView(tv("Welcome, "+player+"!",22)); content.addView(tv("Difficulty: "+difficulty,18));
        if(level==1) house(); else if(level==2) car(); else tractor();
    }
    void house(){content.addView(tv("🏠 LEVEL 1 — BUILD YOUR FIRST HOUSE",20)); content.addView(tv("Complete each construction step to unlock Level 2.",16));
        step=0; nextHouse();}
    void nextHouse(){ Button b=btn("BUILD / PLACE"); content.addView(tv("Step "+(step+1)+": "+new String[]{"Foundation","Walls","Doors & Windows","Roof","Final Inspection"}[step],18)); content.addView(b);
        b.setOnClickListener(v->{step++; if(step>=5){content.addView(tv("🎉 LEVEL 1 COMPLETE! Level 2 unlocked.",20)); Button n=btn("GO TO LEVEL 2");content.addView(n);n.setOnClickListener(x->{level=2;showLevel("Next challenge");});}else nextHouse();});}
    void car(){content.addView(tv("🚗 LEVEL 2 — BUILD A CAR",20)); content.addView(tv("Assemble the parts in order.",16)); step=0; nextCar();}
    void nextCar(){String[] p={"Chassis","Engine","Four Wheels","Doors","Windows","Car Body","Lights"}; if(step>=p.length){content.addView(tv("🏆 CAR COMPLETE! Level 3 unlocked.",20));Button n=btn("GO TO LEVEL 3");content.addView(n);n.setOnClickListener(x->{level=3;showLevel("Next challenge");});return;} content.addView(tv("Part "+(step+1)+": "+p[step],18));Button b=btn("PLACE PART");content.addView(b);b.setOnClickListener(v->{step++;nextCar();});}
    void tractor(){content.addView(tv("🚜 LEVEL 3 — TRACTOR CONSTRUCTION",20));content.addView(tv("Next construction challenge coming in the next build.",16));Button back=btn("BACK TO LEVEL 2");content.addView(back);back.setOnClickListener(v->{level=2;showLevel("Next challenge");});}
}